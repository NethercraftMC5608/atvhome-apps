#!/bin/sh
# atvkit-helper — the root side of ATVHome (installed as /usr/libexec/atvkit-helper).
# launchd runs it at boot, every 30 s, and whenever /var/mobile/Library/ATVHome/request
# changes. ATVHome (which runs as mobile) asks for privileged things by writing one word
# to that file:
#   apple   switch to Apple's interface until the next reboot
#   home    switch back to ATVHome
#   reboot  restart the Apple TV
#   update  install the signed update ATVHome downloaded (see do_update)
#
# Startup screen: /var/mobile/Library/ATVHome/boot-mode holds "home" (default) or "apple";
# Settings writes it, and the first run after each boot applies it.
#
# Safety: if ATVHome crashes 3 times in 3 minutes, switch to Apple's interface for this boot.
#
# Manual use (over SSH):  atvkit-helper apple | home | status | enable | disable
#   enable   boot into ATVHome from now on      disable   boot into Apple's interface again

APPLE=/System/Library/LaunchDaemons/com.apple.frontrow.plist
HOME_JOB=/Library/LaunchDaemons/com.atvkit.home.plist
DIR=/var/mobile/Library/ATVHome
REQ=$DIR/request
LOG=/var/mobile/Library/Logs/atvkit-helper.log
CR=/var/mobile/Library/Logs/CrashReporter

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }
running() { ps ax | grep -v grep | grep -q "$1"; }

# Daemons only Apple's interface needs (iTunes Store, Family/Ask to Buy, Apple ID, iMessage
# identity, usage stats). Stopped while ATVHome runs to free ~40 MB; loaded again for Apple's
# interface. Not -w: nothing is changed permanently. (Bluetooth, Wi-Fi, AirPlay, media stay.)
TRIM="com.apple.itunesstored com.apple.coreduetd com.apple.askpermissiond com.apple.familynotificationd
      com.apple.coreservices.appleid.authentication com.apple.identityservicesd com.apple.rtcreportingd"
trim() {
  # Off unless /var/mobile/Library/ATVHome/trim exists (opt-in until proven safe on every box).
  [ -f "$DIR/trim" ] || return 0
  for j in $TRIM; do launchctl unload "/System/Library/LaunchDaemons/$j.plist" 2>/dev/null; done
  log "stopped Apple interface daemons"
}
untrim() {
  [ -f "$DIR/trim" ] || return 0
  for j in $TRIM; do launchctl load "/System/Library/LaunchDaemons/$j.plist" 2>/dev/null; done
}

# Game controllers: atv-padd owns the Bluetooth chip while it runs (Apple's BTServer is stopped).
PADD=/Library/ATVHome/com.atvkit.padd.plist
BTS=/System/Library/LaunchDaemons/com.apple.BTServer.plist
padd_on()  { [ -f "$PADD" ] || return 0; launchctl load "$PADD" 2>/dev/null; log "controllers on"; }
padd_off() { launchctl unload "$PADD" 2>/dev/null; sleep 1; launchctl load "$BTS" 2>/dev/null; log "controllers off (Bluetooth back to BTServer)"; }
padd_wanted() { [ -f "$DIR/controllers" ]; }

to_apple() {
  log "switching to Apple TV interface"
  launchctl unload "$HOME_JOB" 2>/dev/null
  killall ATVHome Kodi 2>/dev/null
  untrim
  padd_off
  sleep 1
  launchctl load -F "$APPLE"          # -F: load even though it's disabled for boot
}

# Software update. ATVHome (as mobile) downloaded and checked a release into $DIR/update.
# That folder is writable by mobile, so nothing there is trusted: copy it somewhere only root
# can write, check the signature and checksum again on that copy (atvkit-verify), and only
# then unpack and run the release's installer. The outcome goes to $DIR/update/result.
do_update() {
  U=$DIR/update; R=/var/root/atvkit-update; I=/var/root/atvkit-inst
  result() { echo "$(date '+%Y-%m-%d %H:%M') $*" > "$U/result"; chown mobile:mobile "$U/result"; log "update: $*"; }
  rm -rf "$R"; mkdir -p "$R"; chmod 700 "$R"
  if ! cp "$U/manifest.json" "$U/signature.bin" "$U/package.tgz" "$R/" 2>/dev/null; then result "failed: files missing"; return; fi
  if ! /usr/libexec/atvkit-verify "$R/manifest.json" "$R/signature.bin" "$R/package.tgz" >> "$LOG" 2>&1; then
    result "failed: the update didn't pass verification"; rm -rf "$R"; return
  fi
  rm -rf "$I"; mkdir -p "$I"
  if ! tar -xzf "$R/package.tgz" -C "$I"; then result "failed: couldn't unpack"; rm -rf "$R"; return; fi
  V=$(cat "$I/VERSION" 2>/dev/null)
  log "update: installing ATVHome $V"
  if (cd "$I" && ATVKIT_UPDATE=1 sh atv-install-home.sh) >> "$LOG" 2>&1; then result "installed ATVHome $V"
  else result "failed: the installer stopped (see atvkit-helper.log)"; fi
  rm -rf "$R" "$U/package.tgz"
}

# System packages from the Store (apps that need root to install, e.g. Kodi). Same trust as a
# software update: the Store (as mobile) downloads into $DIR/package; root copies the files out
# of reach, checks the release signature and checksum (atvkit-verify), then runs the package's
# install.sh. Outcome: $DIR/package/result.
do_package() {
  P=$DIR/package; R=/var/root/atvkit-pkg; I=/var/root/atvkit-pkg-inst
  result() { echo "$(date '+%Y-%m-%d %H:%M') $*" > "$P/result"; chown mobile:mobile "$P/result"; log "package: $*"; }
  rm -rf "$R"; mkdir -p "$R"; chmod 700 "$R"
  if ! cp "$P/manifest.json" "$P/signature.bin" "$P/package.tgz" "$R/" 2>/dev/null; then result "failed: files missing"; return; fi
  if ! /usr/libexec/atvkit-verify "$R/manifest.json" "$R/signature.bin" "$R/package.tgz" >> "$LOG" 2>&1; then
    result "failed: the package didn't pass verification"; rm -rf "$R"; return
  fi
  rm -rf "$I"; mkdir -p "$I"
  if ! tar -xzf "$R/package.tgz" -C "$I"; then result "failed: couldn't unpack"; rm -rf "$R"; return; fi
  N=$(cat "$I/NAME" 2>/dev/null)
  log "package: installing $N"
  if [ -f "$I/install.sh" ] && (cd "$I" && sh install.sh) >> "$LOG" 2>&1; then result "installed $N"
  else result "failed: the installer stopped (see atvkit-helper.log)"; fi
  rm -rf "$R" "$I" "$P/package.tgz"
}

to_home() {
  log "switching to ATVHome"
  launchctl unload "$APPLE" 2>/dev/null
  killall AppleTV 2>/dev/null
  trim
  padd_wanted && padd_on
  sleep 1
  launchctl load -F "$HOME_JOB"
}

case "$1" in
  apple) to_apple; exit 0 ;;
  home) to_home; exit 0 ;;
  enable)
    launchctl unload -w "$APPLE" 2>/dev/null; launchctl load -w "$HOME_JOB"; log "ATVHome enabled at boot"; exit 0 ;;
  disable)
    launchctl unload -w "$HOME_JOB" 2>/dev/null; killall ATVHome Kodi 2>/dev/null; launchctl load -w "$APPLE"
    log "ATVHome disabled; Apple TV interface at boot"; exit 0 ;;
  status)
    ps ax | grep -E "[A]TVHome.app|[A]ppleTV.app|[K]odi.app"; tail -5 "$LOG"; exit 0 ;;
esac

mkdir -p "$DIR"; chown mobile:mobile "$DIR"

# Log rotation, every 10 minutes: a log over 1 MB keeps its last 256 KB as <name>.1 and starts
# again empty. Truncated in place, not moved: ATVHome and launchd keep the files open for
# appending, so they carry on writing into the same (now empty) file.
LOGS=/var/mobile/Library/Logs
STAMP=$DIR/.log-rotate
if [ -z "$(find "$STAMP" -mmin -10 2>/dev/null)" ]; then
  touch "$STAMP"
  find "$LOGS" -maxdepth 1 -type f \( -name '*.log' -o -name '*.stderr' -o -name '*.out' \) -size +1024k 2>/dev/null |
  while read -r f; do
    tail -c 262144 "$f" > "$f.1" && chown mobile:mobile "$f.1"
    : > "$f"
    log "rotated $(basename "$f")"
  done
fi

# 0. Once per boot: apply the chosen startup screen.
BOOT_ID=$(sysctl -n kern.boottime 2>/dev/null | sed 's/^{ sec = \([0-9]*\),.*/\1/')
if [ -n "$BOOT_ID" ] && [ "$BOOT_ID" != "$(cat "$DIR/.boot-id" 2>/dev/null)" ]; then
  echo "$BOOT_ID" > "$DIR/.boot-id"
  if [ "$(cat "$DIR/boot-mode" 2>/dev/null)" = apple ]; then
    log "startup screen is Apple TV"; to_apple; exit 0
  fi
  trim                                  # booting into ATVHome
  padd_wanted && padd_on
fi

# 1. Requests from ATVHome.
if [ -s "$REQ" ]; then
  R=$(head -1 "$REQ" | tr -d ' \r\n'); rm -f "$REQ"
  case "$R" in
    apple) to_apple ;;
    home) to_home ;;
    reboot) log "reboot requested"; sync; reboot ;;
    update) do_update ;;
    package) do_package ;;
    controllers-on) touch "$DIR/controllers"; chown mobile "$DIR/controllers"; padd_on ;;
    controllers-off) rm -f "$DIR/controllers"; padd_off ;;
    *) log "ignored request '$R'" ;;
  esac
  exit 0
fi

# 2. Crash watchdog: 3+ ATVHome crash reports in the last 3 minutes -> Apple's interface.
# Skipped until the clock is set: right after boot the date is 1970 and every old report would
# look recent (that false alarm once switched a freshly rebooted box to Apple's interface).
if [ "$(date +%Y)" -ge 2020 ] && { running "ATVHome.app/ATVHome" || launchctl list | grep -q com.atvkit.home; }; then
  N=$(find "$CR" -name 'ATVHome_*' -mmin -3 -newer /var/mobile/Library/ATVHome/.boot-id 2>/dev/null | wc -l | tr -d ' ')
  if [ "${N:-0}" -ge 3 ]; then log "ATVHome crashed $N times in 3 min"; to_apple; exit 0; fi
fi

# 3. Never leave the screen empty: if neither interface is running, start Apple's.
if ! running "ATVHome.app/ATVHome" && ! running "AppleTV.app/AppleTV"; then
  sleep 10
  if ! running "ATVHome.app/ATVHome" && ! running "AppleTV.app/AppleTV"; then
    log "no interface running"; to_apple
  fi
fi
exit 0
