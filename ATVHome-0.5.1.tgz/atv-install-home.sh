#!/bin/sh
# Runs ON the Apple TV (sent by `make install`). Installs ATVKit, ATVHome, the apps and the
# root helper. Does not change what boots — run `atvkit-helper enable` for that.
set -e
cd "$(dirname "$0")"

# Stop any old test session (atv-hometest.sh) and its auto-restore watcher.
for p in $(ps ax | grep -E "[s]leep [0-9]+; i=|[w]hile \[" | awk '{print $1}'); do kill "$p" 2>/dev/null || true; done
launchctl unload /tmp/com.atvkit.home.plist 2>/dev/null || true

install -m 755 libATVKit.dylib /usr/lib/libATVKit.dylib
RUNNING=$(ps ax | grep -c "[A]TVHome.app/ATVHome" || true)
rm -rf /Applications/ATVHome.app && cp -R ATVHome.app /Applications/ && chown -R root:wheel /Applications/ATVHome.app
chmod 755 /Applications/ATVHome.app/ATVHome
mkdir -p /Library/ATVHome/Apps
if [ -d roots ]; then rm -rf /Library/ATVHome/roots && cp -R roots /Library/ATVHome/roots && chmod -R a+rX /Library/ATVHome/roots; fi
if [ -d fonts ]; then rm -rf /Library/ATVHome/Fonts && cp -R fonts /Library/ATVHome/Fonts && chmod -R a+rX /Library/ATVHome/Fonts; fi
for a in *.tvapp; do rm -rf "/Library/ATVHome/Apps/$a"; cp -R "$a" /Library/ATVHome/Apps/; done
# The "ATVHome" tile inside Apple's interface (opening it switches back to ATVHome).
if [ -d ATVHome.frappliance ]; then
  rm -rf /Applications/ATVHome.frappliance && cp -R ATVHome.frappliance /Applications/ && chown -R root:wheel /Applications/ATVHome.frappliance
  mkdir -p /Applications/AppleTV.app/Appliances
  # -n: replace the link itself (plain -f follows an existing link to a folder and nests one inside).
  ln -sfn /Applications/ATVHome.frappliance /Applications/AppleTV.app/Appliances/ATVHome.frappliance
fi
install -m 755 atvkit-helper.sh /usr/libexec/atvkit-helper
if [ -f atvkit-verify ]; then install -m 755 -o root -g wheel atvkit-verify /usr/libexec/atvkit-verify; fi
if [ -f VERSION ]; then install -m 644 VERSION /Library/ATVHome/VERSION; fi
if [ -f atv-padd ]; then install -m 755 atv-padd /usr/libexec/atv-padd; install -m 644 com.atvkit.padd.plist /Library/ATVHome/com.atvkit.padd.plist; fi
for p in com.atvkit.home.plist com.atvkit.helper.plist; do install -m 644 -o root -g wheel "$p" /Library/LaunchDaemons/; done
mkdir -p /var/mobile/Library/ATVHome && chown mobile:mobile /var/mobile/Library/ATVHome
# Drawn images cached at boot (wallpaper, icons): redrawn by the new build.
rm -rf /var/mobile/Library/ATVHome/cache
su mobile -c uicache >/dev/null 2>&1 || true

# During a software update the helper itself is running this script: reloading its job would
# stop it halfway. Its new script is picked up on its next run anyway.
if [ -z "$ATVKIT_UPDATE" ]; then
  launchctl unload /Library/LaunchDaemons/com.atvkit.helper.plist 2>/dev/null || true
  launchctl load /Library/LaunchDaemons/com.atvkit.helper.plist
fi
# If ATVHome is the running interface, restart it so the new build takes over.
if [ "$RUNNING" -gt 0 ]; then launchctl unload /Library/LaunchDaemons/com.atvkit.home.plist 2>/dev/null || true; killall ATVHome 2>/dev/null || true; sleep 1; launchctl load -F /Library/LaunchDaemons/com.atvkit.home.plist; fi
echo "installed: ATVHome, $(ls /Library/ATVHome/Apps | tr '\n' ' ')helper"
